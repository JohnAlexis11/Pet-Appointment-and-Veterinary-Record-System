-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2024 at 05:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petlandia1`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `reason` text NOT NULL,
  `status` enum('Pending','Confirmed','Completed','Cancelled') DEFAULT 'Pending',
  `created_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `owner_id`, `pet_id`, `appointment_date`, `appointment_time`, `reason`, `status`, `created_by`, `notes`, `created_at`) VALUES
(34, 29, 32, '2024-07-31', '13:00:00', 'Check Up', 'Pending', 4, NULL, '2024-07-27 05:08:38'),
(35, 30, 33, '2024-07-28', '08:00:00', 'Vaccine', 'Completed', 4, NULL, '2024-07-27 05:10:24'),
(37, 32, 35, '2024-07-30', '13:00:00', 'aaa', 'Cancelled', 4, NULL, '2024-07-27 12:08:22');

-- --------------------------------------------------------

--
-- Table structure for table `file_records`
--

CREATE TABLE `file_records` (
  `file_id` int(11) NOT NULL,
  `owner_name` varchar(100) NOT NULL,
  `pet_name` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `microchip_no` varchar(100) DEFAULT NULL,
  `created_by` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `file_records`
--

INSERT INTO `file_records` (`file_id`, `owner_name`, `pet_name`, `address`, `contact_number`, `email`, `color`, `microchip_no`, `created_by`, `created_at`) VALUES
(2, 'John Alexis Amponin', 'Black', 'Bulacan', '123', '', '', '', 'staff1', '2024-07-28 08:54:00');

-- --------------------------------------------------------

--
-- Table structure for table `owners`
--

CREATE TABLE `owners` (
  `owner_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`owner_id`, `first_name`, `last_name`, `address`, `contact_number`, `email`, `created_at`) VALUES
(29, 'John Alexis', ' Amponin', 'Bulacan', '09123345456', 'test@gmail', '2024-07-27 05:07:53'),
(30, 'Jhazen', ' Duenas', 'Marilao', '01234556', 'test@gmail', '2024-07-27 05:09:32'),
(31, 't', 't', 't', 't', 'test@gmail', '2024-07-27 12:06:37'),
(32, 'Reymark', 'Geronimo', 'Bulacan', '012345678', 'test@gmail', '2024-07-27 12:07:23');

-- --------------------------------------------------------

--
-- Table structure for table `pets`
--

CREATE TABLE `pets` (
  `pet_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `pet_name` varchar(100) NOT NULL,
  `species` varchar(50) NOT NULL,
  `breed` varchar(100) DEFAULT NULL,
  `sex` enum('Male','Female') NOT NULL,
  `age` int(11) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `microchip_no` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pets`
--

INSERT INTO `pets` (`pet_id`, `owner_id`, `pet_name`, `species`, `breed`, `sex`, `age`, `birthdate`, `color`, `microchip_no`, `created_at`) VALUES
(32, 29, 'White', 'Dog', 'Aspin', 'Male', 3, NULL, 'White', 'None', '2024-07-27 05:08:38'),
(33, 30, 'Black', 'Cat', 'British Short Hair', 'Female', 1, NULL, 'Brown And White', 'None', '2024-07-27 05:10:24'),
(34, 32, 'Test', 'Test', 'test', 'Male', 1, NULL, 'brown', '1', '2024-07-27 12:08:22'),
(35, 32, 'Test', 'Test', 'test', 'Male', 1, NULL, 'brown', '1', '2024-07-27 12:08:22');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role`, `created_at`) VALUES
(1, 'admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'admin', '2024-07-23 09:24:56'),
(2, 'staff', '10176e7b7b24d317acfcf8d2064cfd2f24e154f7b5a96603077d5ef813d6a6b6', 'staff', '2024-07-23 09:24:56'),
(3, 'admin1', '$2y$10$dcImsdtKkKc0oqqhv8qWu.1WXSomS1GbxAeS4KiH//bqnJnrA4kKy', 'admin', '2025-09-25 06:26:20'),
(4, 'staff1', '$2y$10$GSPc6KLJVOurmKxg07T3ludHruNf32J/ztbXGoIIljL7NzMZCiCCy', 'staff', '2025-09-25 06:26:20'),
(5, 'admin0', '$2y$10$tBO6gSdLXY6AVAZoyRXboOj.P0XyqJIoiZf1CtXHQoOb2evY0YwUy', 'admin', '2024-07-26 11:49:59'),
(6, 'staff0', '$2y$10$yzQYKh3BoFgISRx2/Jx/E.N79C7vRXEGFRptkaGQJ6BoDr5bj7nbG', 'staff', '2024-07-26 11:50:10'),
(8, 'testta', '$2y$10$mqMxJZkQk9zQ3EUWCR65FOC9fIWbE.hOVSjHzVnGT4WjBm6DWg7iG', 'admin', '2024-07-27 03:15:41');

-- --------------------------------------------------------

--
-- Table structure for table `vet_records`
--

CREATE TABLE `vet_records` (
  `record_id` int(11) NOT NULL,
  `owner_name` varchar(100) NOT NULL,
  `pet_name` varchar(100) NOT NULL,
  `species` varchar(50) NOT NULL,
  `breed` varchar(100) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `sex` enum('Male','Female') DEFAULT NULL,
  `diagnosis` text NOT NULL,
  `treatment` text NOT NULL,
  `remarks` text DEFAULT NULL,
  `recorded_by` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vet_records`
--

INSERT INTO `vet_records` (`record_id`, `owner_name`, `pet_name`, `species`, `breed`, `age`, `sex`, `diagnosis`, `treatment`, `remarks`, `recorded_by`, `created_at`) VALUES
(12, 'John Alexis Amponin', 'Black', 'aa', 'aa', 2, 'Male', 'aa', 'aa', 'aa', 'staff1', '2024-07-28 11:40:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `owner_id` (`owner_id`),
  ADD KEY `pet_id` (`pet_id`);

--
-- Indexes for table `file_records`
--
ALTER TABLE `file_records`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `owners`
--
ALTER TABLE `owners`
  ADD PRIMARY KEY (`owner_id`);

--
-- Indexes for table `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`pet_id`),
  ADD KEY `owner_id` (`owner_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `vet_records`
--
ALTER TABLE `vet_records`
  ADD PRIMARY KEY (`record_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `file_records`
--
ALTER TABLE `file_records`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `owners`
--
ALTER TABLE `owners`
  MODIFY `owner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `pets`
--
ALTER TABLE `pets`
  MODIFY `pet_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `vet_records`
--
ALTER TABLE `vet_records`
  MODIFY `record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `owners` (`owner_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`pet_id`) REFERENCES `pets` (`pet_id`) ON DELETE CASCADE;

--
-- Constraints for table `pets`
--
ALTER TABLE `pets`
  ADD CONSTRAINT `pets_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `owners` (`owner_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
