<?php
session_start();

// Restrict access: only admin
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// DB connection
$conn = new mysqli('localhost', 'petlandia_user1', '@SecurePass123', 'petlandia1');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get record ID
$record_id = $_GET['id'] ?? 0;

if ($record_id > 0) {
    $stmt = $conn->prepare("DELETE FROM file_records WHERE file_id = ?");
    $stmt->bind_param("i", $record_id);
    $stmt->execute();
    $stmt->close();
}

// Redirect back to the admin file records page
header("Location: veterinary_records_admin.php");
exit();
